================================
Drunken Raccoon Productions File
================================

File Name      : misty.zip
File Type      : skybox
Author         : aXon
Email          : axon@drunkencoon.com
Web Site       : http://axon.drunkencoon.com
Created with   : Terragen (http://www.planetside.co.uk/)
Formats        : 256^2 24-bit Targa

===========
Description
===========

This is a landscape down by the ocean on a foggy morning.
There are some large rocks off to the side and fog in most directions,
except for the ocean below you.

=====
Notes
=====

To use this skybox, put it in your gfx/env dir in either a 
PAK file or the appropriate directory in your Half-Life dir 
(usually valve/).

You may NOT use these images, as a skybox or otherwise, in any 
form of released work, without giving me due credit in either 
the map's included text file, in the map itself, or in some 
other way easily seen by anyone playing the map set, looking 
at the images on your web site, etc.

I am no lawyer, but I think you get the idea. You have to 
credit me in some way. Also, I would greatly appreciate it if 
you'd email me and tell me if you're using the sky. This gives 
me the incentive to make more. :]