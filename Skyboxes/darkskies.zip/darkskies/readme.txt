Dark Skies
An environment map by [WTF?]Mr-Gibs

    * Updated 2004-03-31
    * Check out other great artwork by [WTF?]Mr-Gibs
    * Send email to [WTF?]Mr-Gibs: mr-gibs@columbus.rr.com
    * Visit [WTF?]Mr-Gibs's homepage
    * Check out other great environment maps with the same theme: Wild & crazy skies

This idea started as a planned Team Fortress Classic level, which unfortunately never was completed. It does make a nice environment map for a floater level though!

This environment map is in the public domain, and can be used freely in this format in non-commercial projects. For commercial projects or conversions to another format, please contact the artist.
